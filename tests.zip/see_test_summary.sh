#!/bin/bash


if [ "$1" == "" ] 
then
    echo syntax $0 db_name
    exit
fi

DBNAME=$1

for MODULE in globals arrays for_each simple_sp syntax undocumented 
    do 
        echo $MODULE 
        mysql -t $DBNAME < test_$MODULE.mysql | tail -n 5 
    done

